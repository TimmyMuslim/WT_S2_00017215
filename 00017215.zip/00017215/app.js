const express = require('express');
const fs = require("fs");
const path = require("path")
const app = express();
const router = express.Router();
const bodyParser = require('body-parser')
app.use(express.static(__dirname + '\\public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use('/', router);

//get all blogs
app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname, 'public','index.html'))
})
app.get('/bloger',(req,res)=>{
    res.sendFile(path.join(__dirname, 'public','blogger.html'));
})
app.get('/api/blogs', (req, res) => {
    fs.readFile("blogs.json", (err, data) => {
        if (err) {
            return console.error(err);
        } else {
            const blogs = JSON.parse(data);
            res.send(blogs);
        }
    });
});

//get a single blog
app.get('/api/blogs/:id', (req, res) => {
    fs.readFile("blogs.json", (err, data) => {
        if (err) {
            return console.error(err);
        } else {
            const blogs = JSON.parse(data);
            const blog = blogs.find(e => e.id === +req.params.id);
            if (!blog) return res.send("there is no such blog");
            else {
                res.send(blog);
            }
        }
    });
});

//edit a single blog
app.put('/api/blogs/:id', (req, res) => {
    console.log(req.body)
    fs.readFile("blogs.json", (err, data) => {
        if (err) {
            return console.error(err);
        } else {
            const blogs = JSON.parse(data);
            const blog = blogs.find(e => e.id === +req.params.id);
            if (!blog) return res.send("there is no such blog");
            else {
                blog.title = req.body.title;
                blog.text = req.body.text;
                fs.writeFile("blogs.json", JSON.stringify(blogs, null, 2), (err, result) => {
                    if (err) {
                        return console.error(err);
                    } else {
                        res.send("the blog is edited successfully");
                    }
                });
            }
        }
    });
});

//delete a single blog
app.delete('/api/blogs/:id', (req, res) => {
    fs.readFile("blogs.json", (err, data) => {
        if (err) {
            return console.error(err);
        } else {
            const blogs = JSON.parse(data);
            const blog = blogs.find(e => e.id === +req.params.id);
            if (!blog) return res.send("there is no such blog");
            else {
                blogs.splice(blogs.indexOf(blog), 1);

                fs.writeFile("blogs.json", JSON.stringify(blogs, null, 2), (err, result) => {
                    if (err) {
                        return console.error(err);
                    } else {
                        res.send("the blog is removed successfully");
                    }
                });
            }
        }
    });
});

//add a new blog
app.post('/api/blogs', (req, res) => {
    console.log(req.body);
    fs.readFile("blogs.json", (err, data) => {
        if (err) {
            return console.error(err);
        } else {
            const blogs = JSON.parse(data);
            blogs.push({
                "id": blogs.length + 1,
                "title": req.body.title,
                "text": req.body.text
            });
            fs.writeFile("blogs.json", JSON.stringify(blogs, null, 2), (err, result) => {
                if (err) {
                    return console.error(err);
                } else {
                    res.send("the blog is added successfully");
                }

            });
        }
    });
});


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`listening on port ${port}`));